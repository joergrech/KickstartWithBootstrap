@artifact.package@/**
 * @artifact.name@
 * A service class encapsulates the core business logic of a Grails application
 */
class @artifact.name@ {

    static transactional = true

    def serviceMethod() {

    }
}
