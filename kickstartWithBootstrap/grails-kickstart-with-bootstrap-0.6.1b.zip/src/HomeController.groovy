class HomeController {

    def index = {
		render(view:"index")
	}
	
}
