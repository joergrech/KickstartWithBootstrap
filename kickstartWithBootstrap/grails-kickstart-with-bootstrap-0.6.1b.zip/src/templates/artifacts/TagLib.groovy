@artifact.package@/**
 * @artifact.name@
 * A taglib library provides a set of reusable tags to help rendering the views.
 */
class @artifact.name@ {

}
